ZSNES PPC 1.0 for Yellow Dog Linux 3 (PowerPC)

Run it from a terminal in X:
    ./zsnes "/path/to/game.smc"

KEYS (the Mac OS 9 build's, with Control for Command)
    Esc             ZSNES menu
    Ctrl-F          frame counter on/off
    Ctrl-Shift-F    window <-> full screen (Alt-Enter does the same)

VIDEO MODES (Config > Video)
Modes with an O use OpenGL: the graphics card scales the picture.
- 512x448 ODR W, 768x672 ODR W ...: fixed windows.
- VARIABLE ODR W / ODS W: a window you can resize to any size.
- 640x480 ODS F, 800x600 ODS F, 1024x768 ODS F ...: full screen at that
  resolution.
They need OpenGL drawn by the graphics card (XFree86's DRI). If OpenGL is
missing, or only Mesa's software renderer is there, ZSNES says so in the
terminal and the O modes fall back to the 512x448 window; its own software
modes are faster than software OpenGL. To try them anyway:
    ZSNES_SDL12_SOFTGL=1 ./zsnes ...
The OpenGL modes do not wait for the monitor's refresh (that halves the
frame rate on a monitor not running at 60 Hz). To wait anyway, on an SDL of
1.2.10 or later:
    ZSNES_SDL12_VSYNC=1 ./zsnes ...

SOUND
ZSNES plays straight to the sound card when it can (ALSA, then OSS
/dev/dsp), and through a sound server (aRts, ESD) only when the card is
busy; it says in the terminal which it used. On Yellow Dog Linux 3, aRts
stuttered under ZSNES's load, so to keep it off the card while you play:
    artsshell suspend
before starting ZSNES (artsd keeps running and takes the card back when a
KDE program next plays something), or in KDE Control Center > Sound System
turn on "Auto-suspend if idle". SDL_AUDIODRIVER=arts forces aRts anyway.
If aRts fails with "loading the aRts backend /usr/lib/libartscbackend.la
failed", that file is missing; recreating it (it describes
libartscbackend.so.0) fixes aRts for every program.

ALSO
- Fixed (ZSNES PPC 1.0): on the 2.4 kernel, no snow in the menu and a black
  screen in games. Linux 2.4 lacks the clock ZSNES timed its frames with,
  so time stood still; it now falls back to the ordinary clock.
- Fixed: the hang after the first frame in full screen (ZSNES no longer
  asks X to grab the mouse pointer).
- Faster sprite, Mode 7 and background drawing.
- Sound falls back to any SDL driver that works (ALSA, OSS, ESD, aRts).
